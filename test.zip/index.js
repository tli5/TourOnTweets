<!doctype html>

<html ng-app>
  <head>
    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.3.14/angular.min.js"></script>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>

  </head>
  <body>
    <div>
      <label>Name:</label>
      <input type="text" placeholder="Enter info here">
      <input id="button" type="button" value="greet">
      <hr>
      <h1 id="text"></h1>
    </div>
  </body>
  <script>
    	$('#button').click( function(){
    		$("#text").html("<p>hello</p>");
    	});
		

	</script>
</html>